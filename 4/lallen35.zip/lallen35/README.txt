The code and data are in the frozenlake and frozenlake-8x8 folders.

I modified all of the code that I used to output CSVs and try a bunch of different hyperparameters.

The policy iteration code was taken from: https://gist.github.com/lucisdp/1b07c63dda740d50f91e6e44403b7072
The value iteration code was taken from somewhere on Github but I can't find the source. 

To run the code, use Python 2.7.x and run `pip install -U gym numpy` beforehand.
